/*
    Code sample for SITE 1101 Principles of Information Systems 
    (c)2024 by Araz Yusubov 
    DISCLAIMER: All code examples we will look at are quick hacks intended to present working prototypes.
    Hence they do not follow best practice of programming or software engineering.    
*/

// Global variables for Artist's position and orientation
var x, y;
var angle;

function radian(degree) {
    return degree * Math.PI / 180;
}

function moveForward(distance, context) {
    let a = radian(angle);
    x = x + distance * Math.cos(a);
    y = y + distance * Math.sin(a);
    context.lineTo(x, y);    
}

function turnRight(degree) {
    angle = angle - degree;
    if (angle < 0) angle = angle + 360;
}

function turnLeft(degree) {
    angle = angle + degree;
    if (angle > 360) angle = angle - 360;
}

function DrawSpiral(context) {
    // Inspired by Express Course (2024) Lesson 29: For Loops with Artist
    // https://studio.code.org/s/express-2024/lessons/29/levels/5

    // The initial position is in the center of the canvas
    x = context.canvas.width / 2;
    y = context.canvas.height / 2;
    // The initial orientation is zero degrees i.e. facing East
    angle = 0.0; 
    context.moveTo(x, y);
    context.beginPath();
    for (let counter = 3; counter < 600; counter += 3) {
        moveForward(counter, context);
        context.stroke();
        turnRight(89);
    }
}

// Elnara
const elnaraButton = document.getElementById("elnara-btn");
const elnaraInfo = document.getElementById("info-box-elnara");
elnaraButton.onclick = function () {
  if (elnaraInfo.style.display === "block") {
    elnaraInfo.style.display = "none";
  } else {
    elnaraInfo.style.display = "block";
  }
};

// Artsiom
const ArtsiomButton = document.getElementById("artsiom-btn");
const ArtsiomInfo = document.getElementById("info-box-artsiom");
ArtsiomButton.onclick = function () {
  if (ArtsiomInfo.style.display === "block") {
    ArtsiomInfo.style.display = "none";
  } else {
    ArtsiomInfo.style.display = "block";
  }
};

// Kanan
const kananButton = document.getElementById("kanan-btn");
const kananInfo = document.getElementById("info-box-kanan");
kananButton.onclick = function () {
  if (kananInfo.style.display === "block") {
    kananInfo.style.display = "none";
  } else {
    kananInfo.style.display = "block";
  }
};

// Subhan
const subhanButton = document.getElementById("subhan-btn");
const subhanInfo = document.getElementById("info-box-subhan");
subhanButton.onclick = function () {
  if (subhanInfo.style.display === "block") {
    subhanInfo.style.display = "none";
  } else {
    subhanInfo.style.display = "block";
  }
};

function DrawSpiral(context) {
  const centerX = 470; 
  const centerY = 310; 
  const numLines = 280; 
  const step = 1; 

  for (let i = 0; i < numLines; i++) {
    const angle = (Math.PI * 2 * i) / numLines; // Angle in radians
    const x1 = centerX + i * Math.cos(angle); // Start point x
    const y1 = centerY + i * Math.sin(angle); // Start point y
    const x2 = centerX + (i + step) * Math.cos(angle + Math.PI / 6); // End point x
    const y2 = centerY + (i + step) * Math.sin(angle + Math.PI / 6); // End point y

    context.beginPath();
    context.moveTo(x1, y1); // Move to the start point
    context.lineTo(x2, y2); // Draw the line to the end point
    context.stroke(); // Apply the stroke style
  }
}